package com.example.walkable;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class chineseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chinese);


        Button sub4 = (Button) findViewById(R.id.sub4);
        sub4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                CheckBox pizza, spaghetti, lasagna, ravioli;

                pizza = findViewById(R.id.pizza4);
                spaghetti = findViewById(R.id.spaghetti4);
                lasagna = findViewById(R.id.lasanga4);
                ravioli = findViewById(R.id.ravioli4);

                if(!pizza.isChecked()){
                    MainActivity.blackList.add("Chow Mein");
                }

                if(!spaghetti.isChecked()){
                    MainActivity.blackList.add("Spring Rolls");
                }

                if(!lasagna.isChecked()){
                    MainActivity.blackList.add("Dumplings");

                }

                if(!ravioli.isChecked()){
                    MainActivity.blackList.add("Fried Rice");

                }



                chineseActivity.this.finish();
            }
        });
    }
}



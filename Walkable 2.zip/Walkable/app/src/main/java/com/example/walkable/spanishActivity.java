package com.example.walkable;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class spanishActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spanish);

        Button sub5 = (Button) findViewById(R.id.sub5);
        sub5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                CheckBox pizza, spaghetti, lasagna, ravioli;
                pizza = findViewById(R.id.pizza);
                spaghetti = findViewById(R.id.spaghetti);
                lasagna = findViewById(R.id.lasanga);
                ravioli = findViewById(R.id.ravioli);

                if(!pizza.isChecked()){
                    MainActivity.blackList.add("Paella");
                }

                if(!spaghetti.isChecked()){
                    MainActivity.blackList.add("Churros");
                }

                if(!lasagna.isChecked()){
                    MainActivity.blackList.add("Tortilla");

                }

                if(!ravioli.isChecked()){
                    MainActivity.blackList.add("Gazpacho");

                }



                spanishActivity.this.finish();
            }
        });
    }
}

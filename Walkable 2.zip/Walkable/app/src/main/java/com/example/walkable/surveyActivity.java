package com.example.walkable;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class surveyActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    public static String italian;
    public static String mexican;
    public static String chinese;
    public static String spanish;
    public static String american;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);

        final Spinner italianSpin = (Spinner) findViewById(R.id.italianSpin);
        final Spinner mexiSpin = (Spinner) findViewById(R.id.mexiSpin);
        final Spinner chineseSpin = (Spinner) findViewById(R.id.chineseSpin);
        final Spinner spanishSpin = (Spinner) findViewById(R.id.spanishSpin);
        final Spinner americanSpin = (Spinner) findViewById(R.id.americanSpin);

        italianSpin.setOnItemSelectedListener(this);
        mexiSpin.setOnItemSelectedListener(this);
        chineseSpin.setOnItemSelectedListener(this);
        spanishSpin.setOnItemSelectedListener(this);
        americanSpin.setOnItemSelectedListener(this);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.choices, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        italianSpin.setAdapter(adapter);
        mexiSpin.setAdapter(adapter);
        chineseSpin.setAdapter(adapter);
        spanishSpin.setAdapter(adapter);
        americanSpin.setAdapter(adapter);

        italianSpin.setOnItemSelectedListener(this);
        mexiSpin.setOnItemSelectedListener(this);
        chineseSpin.setOnItemSelectedListener(this);
        spanishSpin.setOnItemSelectedListener(this);
        americanSpin.setOnItemSelectedListener(this);

        Button submitButton = (Button) findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                italian = italianSpin.getSelectedItem().toString();
                chinese = chineseSpin.getSelectedItem().toString();
                spanish = spanishSpin.getSelectedItem().toString();
                american = americanSpin.getSelectedItem().toString();
                mexican = mexiSpin.getSelectedItem().toString();



                openCalculationActivity();

                if(!"Bad".equals(italian)){
                    if("Good".equals(italian)){
                        MainActivity.types.put("Italian", 1.0);
                    }
                    else if("Neutral".equals(italian)){
                        MainActivity.types.put("Italian", 0.5);

                    }
                    italianActivity();
                }
                else{
                    MainActivity.types.put("Italian", 0.0);
                    MainActivity.blackList.add("Pizza");
                    MainActivity.blackList.add("Spaghetti");
                    MainActivity.blackList.add("Lasagna");
                    MainActivity.blackList.add("Ravioli");
                }

                if(!"Bad".equals(mexican)){
                    if("Good".equals(mexican)){
                        MainActivity.types.put("Mexican", 1.0);
                    }
                    else if("Neutral".equals(mexican)){
                        MainActivity.types.put("Mexican", 0.5);

                    }
                    mexicanActivity();
                }
                else{
                    MainActivity.types.put("Mexican", 0.0);
                    MainActivity.blackList.add("Tacos");
                    MainActivity.blackList.add("Quesadillas");
                    MainActivity.blackList.add("Fajitas");
                    MainActivity.blackList.add("Burritos");
                }

                if(!"Bad".equals(chinese)){
                    if("Good".equals(chinese)){
                        MainActivity.types.put("Chinese", 1.0);
                    }
                    else if("Neutral".equals(chinese)){
                        MainActivity.types.put("Chinese", 0.5);

                    }
                    chineseActivity();
                }
                else{
                    MainActivity.types.put("Chinese", 0.0);
                    MainActivity.blackList.add("Chow Mein");
                    MainActivity.blackList.add("Spring Rolls");
                    MainActivity.blackList.add("Dumplings");
                    MainActivity.blackList.add("Fried Rice");
                }

                if(!"Bad".equals(american)){
                    if("Good".equals(american)){
                        MainActivity.types.put("American", 1.0);
                    }
                    else if("Neutral".equals(american)){
                        MainActivity.types.put("American", 0.5);

                    }
                    americanActivity();
                }
                else{
                    MainActivity.types.put("American", 0.0);
                    MainActivity.blackList.add("Hamburger");
                    MainActivity.blackList.add("Chowder");
                    MainActivity.blackList.add("Biscuits");
                    MainActivity.blackList.add("Wings");
                }

                if(!"Bad".equals(spanish)){
                    if("Good".equals(spanish)){
                        MainActivity.types.put("Spanish", 1.0);
                    }
                    else if("Neutral".equals(spanish)){
                        MainActivity.types.put("Spanish", 0.5);

                    }
                    spanishActivity();
                }
                else{
                    MainActivity.types.put("Spanish", 0.0);
                    MainActivity.blackList.add("Paella");
                    MainActivity.blackList.add("Churros");
                    MainActivity.blackList.add("Tortilla");
                    MainActivity.blackList.add("Gazpacho");
                }



            }
        });
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void openCalculationActivity(){
        Intent intent = new Intent(this, calculationActivity.class);
        startActivity(intent);
    }

    public void italianActivity(){
        Intent intent = new Intent(this, italianActivity.class);
        startActivity(intent);
    }

    public void spanishActivity(){
        Intent intent = new Intent(this, spanishActivity.class);
        startActivity(intent);
    }
    public void mexicanActivity(){
        Intent intent = new Intent(this, mexicanActivity.class);
        startActivity(intent);
    }

    public void chineseActivity(){
        Intent intent = new Intent(this, chineseActivity.class);
        startActivity(intent);
    }
    public void americanActivity(){
        Intent intent = new Intent(this, americanActivity.class);
        startActivity(intent);
    }
}

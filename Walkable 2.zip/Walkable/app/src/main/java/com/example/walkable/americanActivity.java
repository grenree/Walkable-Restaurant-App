package com.example.walkable;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class americanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_american);

        Button sub3 = (Button) findViewById(R.id.sub3);
        sub3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                CheckBox pizza, spaghetti, lasagna, ravioli;
                pizza = findViewById(R.id.pizza3);
                spaghetti = findViewById(R.id.spaghetti3);
                lasagna = findViewById(R.id.lasanga3);
                ravioli = findViewById(R.id.ravioli3);

                if(!pizza.isChecked()){
                    MainActivity.blackList.add("Hamburger");
                }

                if(!spaghetti.isChecked()){
                    MainActivity.blackList.add("Chowder");
                }

                if(!lasagna.isChecked()){
                    MainActivity.blackList.add("Biscuits");

                }

                if(!ravioli.isChecked()){
                    MainActivity.blackList.add("Wings");

                }



                americanActivity.this.finish();
            }
        });
    }
}

package com.example.walkable;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class mexicanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mexican);

        Button sub2 = (Button) findViewById(R.id.sub2);
        sub2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                CheckBox pizza, spaghetti, lasagna, ravioli;

                pizza = findViewById(R.id.pizza2);
                spaghetti = findViewById(R.id.spaghetti2);
                lasagna = findViewById(R.id.lasanga2);
                ravioli = findViewById(R.id.ravioli2);

                if(!pizza.isChecked()){
                    MainActivity.blackList.add("Tacos");
                }

                if(!spaghetti.isChecked()){
                    MainActivity.blackList.add("Quesadillas");
                }

                if(!lasagna.isChecked()){
                    MainActivity.blackList.add("Fajitas");

                }

                if(!ravioli.isChecked()){
                    MainActivity.blackList.add("Burritos");

                }



                mexicanActivity.this.finish();
            }
        });
    }
}

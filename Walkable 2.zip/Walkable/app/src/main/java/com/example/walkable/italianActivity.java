package com.example.walkable;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class italianActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_italian);





        Button sub = (Button) findViewById(R.id.sub);
        sub.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                CheckBox pizza, spaghetti, lasagna, ravioli;
                pizza = findViewById(R.id.pizza1);
                spaghetti = findViewById(R.id.spaghetti1);
                lasagna = findViewById(R.id.lasanga1);
                ravioli = findViewById(R.id.ravioli1);

                if(!pizza.isChecked()){
                    MainActivity.blackList.add("Pizza");
                }

                if(!spaghetti.isChecked()){
                    MainActivity.blackList.add("Spaghetti");
                }

                if(!lasagna.isChecked()){
                    MainActivity.blackList.add("Lasagna");

                }

                if(!ravioli.isChecked()){
                    MainActivity.blackList.add("Ravioli");

                }



                italianActivity.this.finish();
            }
        });
    }
}

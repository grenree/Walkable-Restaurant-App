package com.example.walkable;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.HashSet;

public class MainActivity extends AppCompatActivity {
    public static int inches;
    public static int feet;
    public static int weight;

    public static HashMap<String, Double> types;
    public static HashSet<String> blackList;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button submitBtn = (Button) findViewById(R.id.submitBtn);
        submitBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                EditText inputFeet = (EditText) findViewById(R.id.inputFeet);
                EditText inputInches = (EditText) findViewById(R.id.inputInches);
                EditText inputWeight = (EditText) findViewById(R.id.inputWeight);

                inputFeet.setText("0");
                inputInches.setText("0");
                inputWeight.setText("0");

                inches = Integer.parseInt(inputInches.getText().toString());
                feet = Integer.parseInt(inputFeet.getText().toString());
                weight = Integer.parseInt(inputWeight.getText().toString());

                blackList = new HashSet<String>();
                types = new HashMap<String, Double>();

                openSurveyActivity();
            }
        });

    }
    public void openSurveyActivity(){
        Intent intent = new Intent(this, surveyActivity.class);
        startActivity(intent);
    }
}
